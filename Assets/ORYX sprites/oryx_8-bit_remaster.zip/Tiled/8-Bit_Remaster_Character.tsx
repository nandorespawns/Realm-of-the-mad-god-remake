<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="8-Bit_Remaster_Character" tilewidth="12" tileheight="12" tilecount="1056" columns="24">
 <image source="../8-Bit_Remaster_Character.png" width="288" height="528"/>
 <tile id="0">
  <animation>
   <frame tileid="0" duration="500"/>
   <frame tileid="4" duration="500"/>
  </animation>
 </tile>
 <tile id="195">
  <animation>
   <frame tileid="195" duration="500"/>
   <frame tileid="199" duration="500"/>
  </animation>
 </tile>
 <tile id="288">
  <animation>
   <frame tileid="288" duration="1000"/>
   <frame tileid="304" duration="200"/>
   <frame tileid="305" duration="200"/>
  </animation>
 </tile>
 <tile id="552">
  <animation>
   <frame tileid="552" duration="500"/>
   <frame tileid="556" duration="500"/>
  </animation>
 </tile>
 <tile id="555">
  <animation>
   <frame tileid="555" duration="500"/>
   <frame tileid="559" duration="500"/>
  </animation>
 </tile>
 <tile id="648">
  <animation>
   <frame tileid="648" duration="500"/>
   <frame tileid="664" duration="500"/>
   <frame tileid="665" duration="500"/>
  </animation>
 </tile>
 <tile id="768">
  <animation>
   <frame tileid="768" duration="500"/>
   <frame tileid="772" duration="500"/>
  </animation>
 </tile>
 <tile id="817">
  <animation>
   <frame tileid="817" duration="500"/>
   <frame tileid="821" duration="500"/>
  </animation>
 </tile>
 <tile id="867">
  <animation>
   <frame tileid="867" duration="500"/>
   <frame tileid="871" duration="500"/>
  </animation>
 </tile>
 <tile id="915">
  <animation>
   <frame tileid="915" duration="500"/>
   <frame tileid="919" duration="500"/>
  </animation>
 </tile>
</tileset>
