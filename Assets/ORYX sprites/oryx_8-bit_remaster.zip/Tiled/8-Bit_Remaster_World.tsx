<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="8-Bit_Remaster_World" tilewidth="12" tileheight="12" tilecount="253" columns="23">
 <image source="../8-Bit_Remaster_World.png" width="276" height="132"/>
 <tile id="102">
  <animation>
   <frame tileid="102" duration="500"/>
   <frame tileid="103" duration="500"/>
  </animation>
 </tile>
 <tile id="104">
  <animation>
   <frame tileid="104" duration="500"/>
   <frame tileid="105" duration="500"/>
  </animation>
 </tile>
 <tile id="106">
  <animation>
   <frame tileid="106" duration="500"/>
   <frame tileid="107" duration="500"/>
  </animation>
 </tile>
 <tile id="125">
  <animation>
   <frame tileid="125" duration="500"/>
   <frame tileid="126" duration="500"/>
  </animation>
 </tile>
 <tile id="127">
  <animation>
   <frame tileid="127" duration="500"/>
   <frame tileid="128" duration="500"/>
  </animation>
 </tile>
 <tile id="178">
  <animation>
   <frame tileid="178" duration="500"/>
   <frame tileid="179" duration="500"/>
  </animation>
 </tile>
</tileset>
